function vis2(data, div) {
  const margin = {top: 40, right: 20, bottom: 300, left: 65};
  const visWidth = 1250 - margin.left - margin.right;
  const visHeight = 500 - margin.top - margin.bottom;
  
  // ------------------- svg + g ------------------
  const svg = div.append("svg")
      .attr("width", visWidth + margin.left + margin.right)
      .attr("height", visHeight + margin.top + margin.bottom)
      .append("g")
      .attr("transform", "translate(" + margin.left + "," + margin.top + ")");
  
  const g = svg.append('g')
      .attr('transform', `translate(${margin.left}, ${margin.top})`);

  // ------------------ x values ------------------ 
  const x_elements = d3.set(data.map(function(item) { 
      return item.year; 
    }
  )).values();
  // console.log(x_elements);

  const x = d3.scaleBand()
      .domain(x_elements)
      .range([0, visWidth * 0.95])
      .padding(0.25);

  const xAxis = d3.axisBottom(x).tickFormat(d3.timeFormat('%B'));
  
  g.append('g')
      .attr('transform', `translate(0, visHeight)`)
      .call(xAxis)
      .call(g => g.selectAll('.domain').remove());

  // ------------------ y values ------------------ 
  const y = d3.scaleLinear()
      .domain([0, 1]).nice()
      .range([visHeight, 0]);
  
  const yAxis = d3.axisLeft(y).tickFormat(d3.format(".0%"));

  g.append("g")
      .call(yAxis)
      .call(g => g.selectAll('.domain').remove())
    .append('text')
      .attr('fill', 'black')
      .attr('x', -40)
      .attr('y', visHeight / 2)
      .text("Disbursement Amount (%)");

  // -------------------- data -------------------- 
  const purpose = d3.set(data.map(function(item) { 
      return item.purpose; 
    }
  )).values();
  // console.log(purpose);

  const series = g.selectAll('.series')
    .data(data)
    .join('g')
      .attr('fill', d => color(d.key))
      .attr('class', 'series')
    .selectAll('rect')
    .data(d => d)
    .join('rect')
      .attr('y', d => y(d[1]))
      .attr('height', d => y(d[0]) - y(d[1]))
      .attr('x', d => x(d.data.year))
      .attr('width', x.bandwidth());

  // -------------------- color -------------------
  const color = d3.scaleOrdinal()
    .domain(purpose)
    .range(d3.schemeTableau10);
  
  return svg.node();
}




